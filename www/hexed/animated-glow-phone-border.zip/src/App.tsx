/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Battery, Wifi, SignalHigh } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-8 overflow-hidden">
      
      {/* Phone Frame */}
      <div className="relative w-[360px] h-[780px] rounded-[4rem] p-[4px] bg-gradient-to-b from-gray-800 to-black shadow-2xl">
        
        {/* Inner Screen Container */}
        <div className="relative w-full h-full bg-[#0a0a0a] rounded-[3.8rem] overflow-hidden shadow-[inset_0_0_20px_rgba(0,0,0,1)]">
          
          {/* Status Bar (Fixed) */}
          <div className="absolute top-0 left-0 right-0 flex justify-between items-center px-8 pt-5 text-white text-xs font-medium z-40">
            <span>12:44</span>
            <div className="flex items-center gap-1.5">
              <SignalHigh size={14} />
              <Wifi size={14} />
              <Battery size={16} />
            </div>
          </div>

          {/* Dynamic Island (Fixed) */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-[120px] h-[35px] bg-black rounded-full z-40 flex items-center justify-between px-3 shadow-md border border-white/5">
            <div className="w-2.5 h-2.5 rounded-full bg-[#111] border border-[#222]"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-[#0a0a0a] flex items-center justify-center">
              <div className="w-1 h-1 rounded-full bg-blue-500/30"></div>
            </div>
          </div>

          {/* Scrollable Screen Content */}
          <div className="absolute inset-0 z-10 animate-screen-scroll">
            {/* Screen Content - Gradient Background */}
            <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-red-900/10 to-orange-900/20 min-h-[150%]"></div>

            {/* App Grid */}
            <div className="relative px-6 pt-24 pb-32 flex flex-col gap-8">
              <div className="grid grid-cols-4 gap-x-4 gap-y-8">
                {[...Array(28)].map((_, i) => (
                  <div key={i} className="flex flex-col items-center gap-1.5">
                    <div className={`w-14 h-14 rounded-2xl shadow-sm ${
                      i % 4 === 0 ? 'bg-gradient-to-br from-blue-400 to-blue-600' :
                      i % 4 === 1 ? 'bg-gradient-to-br from-green-400 to-green-600' :
                      i % 4 === 2 ? 'bg-gradient-to-br from-pink-400 to-pink-600' :
                      'bg-gradient-to-br from-orange-400 to-orange-600'
                    }`}></div>
                    <div className="w-10 h-1.5 bg-white/20 rounded-full"></div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Dock (Fixed) */}
          <div className="absolute bottom-6 left-4 right-4 z-40 h-[88px] bg-white/10 backdrop-blur-xl rounded-[2.5rem] flex items-center justify-around px-4 border border-white/10">
             {[...Array(4)].map((_, i) => (
                <div key={i} className={`w-[56px] h-[56px] rounded-[1.25rem] ${
                  i === 0 ? 'bg-gradient-to-b from-green-400 to-green-600' :
                  i === 1 ? 'bg-gradient-to-b from-blue-400 to-blue-600' :
                  i === 2 ? 'bg-gradient-to-b from-red-400 to-red-600' :
                  'bg-gradient-to-b from-zinc-400 to-zinc-600'
                }`}></div>
             ))}
          </div>

          {/* Home Indicator (Fixed) */}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-white/50 rounded-full z-40"></div>

          {/* Bubble Glow Glassmorphism Layer (Overlay) */}
          <div className="absolute inset-0 z-50 pointer-events-none animate-bubble-clip">
            {/* Glassmorphism background */}
            <div className="absolute inset-0 backdrop-blur-xl bg-white/5 rounded-[3.8rem]"></div>
            
            {/* Soft Gradient Inner Glow */}
            <div className="absolute inset-0 rounded-[3.8rem] mask-soft-edges">
              <div className="absolute -inset-[100%] animate-spin-slow"
                   style={{
                     background: 'conic-gradient(from 0deg, #ff0080, #ff8c00, #40e0d0, #8a2be2, #ff0080)',
                     opacity: 0.9,
                     filter: 'blur(30px)'
                   }}>
              </div>
            </div>

            {/* Sharp Gradient Border */}
            <div className="absolute inset-0 rounded-[3.8rem] p-[2px] mask-border-only">
              <div className="absolute -inset-[100%] animate-spin-slow"
                   style={{
                     background: 'conic-gradient(from 0deg, #ff0080, #ff8c00, #40e0d0, #8a2be2, #ff0080)',
                   }}>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
